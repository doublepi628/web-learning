package com.functions;

import com.commodities.Commodity;
import java.util.*;

public class SortMap {
    public static List<Map.Entry<Integer, Commodity>> sortMap0(Map<Integer, Commodity> map){
        List<Map.Entry<Integer, Commodity>> list = new ArrayList<>(map.entrySet());
        Collections.sort(list, new Comparator<Map.Entry<Integer, Commodity>>() {
            @Override
            public int compare(Map.Entry<Integer, Commodity> o1, Map.Entry<Integer, Commodity> o2) {
                return o1.getKey() - o2.getKey();
            }
        });
        return list;
    }
}
