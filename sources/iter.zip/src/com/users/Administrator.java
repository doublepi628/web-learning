package com.users;

public class Administrator extends User{

    public Administrator(String cardNumber0, String name0, String password0) {
        super(cardNumber0, name0, password0);
        this.identity = "Administrator";
    }

    @Override
    public String toString() {
        String type;
        return "Name: " + this.name + "\nKakafee number: " + this.cardNumber + "\nType: Administrator";
    }
}
