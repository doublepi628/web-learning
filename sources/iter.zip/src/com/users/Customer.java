package com.users;

import java.util.ArrayList;

public class Customer extends User{

    public Customer(String cardNumber0, String name0, String password0) {
        super(cardNumber0, name0, password0);
        this.identity = "Customer";
        this.orders = new ArrayList<>();
        this.favorites = new ArrayList<>();
    }

    @Override
    public String toString() {
        String type;
        return "Name: " + this.name + "\nKakafee number: " + this.cardNumber + "\nType: Customer";
    }
}
