package com.users;

import java.util.ArrayList;

public class Merchant extends User{
    public Merchant(String cardNumber0, String name0, String password0) {
        super(cardNumber0, name0, password0);
        this.identity = "Merchant";
        this.shops = new ArrayList<>();
        this.orders = new ArrayList<>();
    }

    @Override
    public String toString() {
        String type;
        return "Name: " + this.name + "\nKakafee number: " + this.cardNumber + "\nType: Merchant";
    }
}
