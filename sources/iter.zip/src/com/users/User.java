package com.users;

import com.commodities.Favorite;
import com.orders.Order;
import com.shops.Shop;

import java.util.ArrayList;

public class User {
    public String cardNumber;
    String name;
    public String password;
    public String identity;
    public ArrayList<Shop> shops;
    public ArrayList<Order> orders;
    public ArrayList<Favorite> favorites;

    public User(String cardNumber0, String name0, String password0){
        this.cardNumber = cardNumber0;
        this.name = name0;
        this.password = password0;
    }

    @Override
    public String toString() {
        String type;
        return "Name: " + this.name + "\nKakafee number: " + this.cardNumber + "\nType: " + identity;
    }
}
