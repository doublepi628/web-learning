package com.users.creator;

import com.users.*;

public class UserCreator {
    public static User creat(String cardNumberString, String name, String password0, String identityString) {
        switch (identityString) {
            case "Customer" -> {
                return new Customer(cardNumberString, name, password0);
            }
            case "Merchant" -> {
                return new Merchant(cardNumberString, name, password0);
            }
            case "Administrator" -> {
                return new Administrator(cardNumberString, name, password0);
            }
        }
        return null;
    }
}
