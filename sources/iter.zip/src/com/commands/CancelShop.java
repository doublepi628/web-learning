package com.commands;

import com.judges.ElementJudge;
import com.judges.GrammarJudge;
import com.orders.Order;
import com.server.Server;

import java.util.ArrayList;

public class CancelShop extends Command{
    public String name = "cancelShop";

    public CancelShop(Server s) {
        super(s);
        this.argsNumber = 1;
    }
    @Override
    public int isLegalLogin(ArrayList<String> arg){
        return server.activeUser != null ? 0 : 1;
    }
    @Override
    public boolean isLegalUser(ArrayList<String> args){
        return !this.server.activeUser.identity.equals("Customer");
    }
    @Override
    public void action(ArrayList<String> args){
        if(!GrammarJudge.isLegalShopNumber(args.get(0)))
            System.out.println("Illegal shop id");
        else if(!shopIsExist(Integer.parseInt(args.get(0).substring(2))))
            System.out.println("Shop id not exists");
        else{
            for(Order order: server.shopFactory.shops.get(Integer.parseInt(args.get(0).substring(2)) - 1).orders) {
                if(order.statusNum == 0) {
                    System.out.println("Please process order for shop");
                    return;
                }
            }
            System.out.println("Cancel shop success");
            server.shopFactory.shops.get(Integer.parseInt(args.get(0).substring(2)) - 1).condition = false;
        }
    }

    private boolean shopIsExist(int shopNumber){
        return ElementJudge.shopIsExist(server, shopNumber) &&
                (server.activeUser.identity.equals("Administrator")
                        || server.shopFactory.shops.get(shopNumber - 1).merchant.equals(server.activeUser));
    }
}
