package com.commands;

import com.commodities.Favorite;
import com.server.Server;

import java.util.ArrayList;

public class ListFavoriteCommodity extends Command{

    public ListFavoriteCommodity(Server s) {
        super(s);
        this.argsNumber = 0;
    }
    @Override
    public int isLegalLogin(ArrayList<String> args){
        return server.activeUser != null ? 0 : 1;
    }
    @Override
    public boolean isLegalUser(ArrayList<String> args){
        return this.server.activeUser.identity.equals("Customer");
    }
    @Override public void action(ArrayList<String> args) {
        if (server.activeUser.favorites.isEmpty())
            System.out.println("Favorite not exists");
        else
            for (Favorite favorite: server.activeUser.favorites)
                System.out.println(favorite);
    }
}
