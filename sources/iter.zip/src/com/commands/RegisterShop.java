package com.commands;

import com.judges.GrammarJudge;
import com.server.Server;
import com.shops.Shop;
import java.util.ArrayList;

public class RegisterShop extends Command{
    public String name = "registerShop";
    public RegisterShop(Server s) {
        super(s);
        this.argsNumber = 1;
    }
    @Override
    public int isLegalLogin(ArrayList<String> arg){
        return server.activeUser != null ? 0 : 1;
    }
    @Override
    public boolean isLegalUser(ArrayList<String> args){
        return this.server.activeUser.identity.equals("Merchant");
    }

    @Override
    public void action(ArrayList<String> args){
        String shopName = args.get(0);
        if(this.server.activeUser.shops.size() >= 5)
            System.out.println("Shop count reached limit");
        else if(!GrammarJudge.isLegalName(shopName))
            System.out.println("Illegal shop name");
        else if(isNameExist(shopName))
            System.out.println("Shop name already exists");
        else{
            server.shopFactory.creatShop(shopName, server.activeUser);
            System.out.println("Register shop success (shopId: S-" + this.server.shopFactory.shops.size() + ")");
        }
    }

    private boolean isNameExist(String shopName){
        for(Shop shop: server.activeUser.shops)
            if(shop.name.equals(shopName))
                return true;
        return false;
    }
}
