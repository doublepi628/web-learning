package com.commands;
import java.io.IOException;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.ArrayList;
import com.server.Server;
public class Quit extends Command {
    public String name = "quit";

    public Quit(Server s) {
        super(s);
        this.argsNumber = 0;
    }

    @Override
    public void action(ArrayList<String> args){
        server.working = false;
        System.out.println("----- Good Bye! -----");
        Path path= Paths.get("../data/");
        try {
            Files.walkFileTree(path, new SimpleFileVisitor<>() {
                //遍历删除文件
                public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {
                    Files.delete(file);
                    return FileVisitResult.CONTINUE;
                }

                //遍历删除目录
                public FileVisitResult postVisitDirectory(Path dir, IOException exc) throws IOException {
                    Files.delete(dir);
                    return FileVisitResult.CONTINUE;
                }
            });
        } catch (IOException ignore){}
    }
}
