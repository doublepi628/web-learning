package com.commands;
import java.util.ArrayList;
import com.server.Server;
import com.judges.GrammarJudge;
public class Login extends Command {
    public String name = "login";

    public Login(Server s) {
        super(s);
        this.argsNumber = 2;
    }
    @Override
    public int isLegalLogin(ArrayList<String> args){
        return server.activeUser == null ? 0 : 2;
    }
    @Override
    public void action(ArrayList<String> args){
        String cardNumberString = args.get(0);
        String password = args.get(1);
        if(!GrammarJudge.isLegalCardNumber(cardNumberString))
            System.out.println("Illegal Kakafee number");
        else if(!server.map.containsKey(cardNumberString))
            System.out.println("Kakafee number not exists");
        else if(!server.map.get(cardNumberString).password.equals(password))
            System.out.println("Wrong password");
        else{
            server.activeUser = server.map.get(cardNumberString);
            System.out.println("Welcome to TMS");
        }
    }
}