package com.commands;

import com.judges.ElementJudge;
import com.judges.GrammarJudge;
import com.server.Server;
import com.shops.Shop;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

public class PutCommodityBatch extends Command{

    public PutCommodityBatch(Server s) {
        super(s);
        this.argsNumber = 1;
    }
    @Override
    public int isLegalLogin(ArrayList<String> args){
        return server.activeUser != null ? 0 : 1;
    }
    @Override
    public boolean isLegalUser(ArrayList<String> args){
        return this.server.activeUser.identity.equals("Merchant");
    }
    @Override
    public void action(ArrayList<String> args) {
        if(!GrammarJudge.isLegalShopNumber(args.get(0)))
            System.out.println("Illegal shop id");
        else if(!shopIsExist(Integer.parseInt(args.get(0).substring(2))))
            System.out.println("Shop id not exists");
        else {
            try {
                Shop shop = server.shopFactory.shops.get(Integer.parseInt(args.get(0).substring(2)) - 1);
                Path filePath = Paths.get("commodity.txt");
                List<String> lines = Files.readAllLines(filePath);
                for(String line: lines) {
                    String[] words = line.trim().split("\\s+");
                    server.commodityFactory.creatCommodity(shop, words[0], Double.parseDouble(words[1]), Integer.parseInt(words[2]));
                }
                System.out.println("Put commodity batch success");
            }
            catch(IOException ignore) {}
        }
    }

    private boolean shopIsExist(int shopNumber){
        return ElementJudge.shopIsExist(server, shopNumber) &&
                server.shopFactory.shops.get(shopNumber - 1).merchant.equals(server.activeUser);
    }
}
