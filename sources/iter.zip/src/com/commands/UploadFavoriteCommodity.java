package com.commands;

import com.commodities.Favorite;
import com.server.Server;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;

public class UploadFavoriteCommodity extends Command{
    public String name = "uploadFavoriteCommodity";
    public UploadFavoriteCommodity(Server s) {
        super(s);
        this.argsNumber = 1;
    }
    @Override
    public int isLegalLogin(ArrayList<String> args){
        return server.activeUser != null ? 0 : 1;
    }
    @Override
    public boolean isLegalUser(ArrayList<String> args){
        return this.server.activeUser.identity.equals("Customer");
    }
    @Override
    public void action(ArrayList<String> args) {
        if (server.activeUser.favorites.isEmpty())
            System.out.println("Favorite not exists");
        else {
            try {
                Path parentDirectory = Path.of("../data/" + args.get(0)).getParent();
                if (parentDirectory != null)
                    Files.createDirectories(parentDirectory);
                ObjectOutputStream outputStream = new ObjectOutputStream(new FileOutputStream("../data/" + args.get(0)));
                for (Favorite favorite: server.activeUser.favorites)
                    outputStream.writeObject(favorite);
                System.out.println("Upload favorite commodity success");
            } catch(IOException ignore){ System.out.println("File operation failed"); };
        }
    }
}
