package com.commands;

import com.commodities.Commodity;
import com.commodities.CommodityUnit;
import com.judges.ElementJudge;
import com.judges.GrammarJudge;
import com.server.Server;
import com.shops.Shop;

import java.util.ArrayList;

public class BuyCommodity extends Command{
    public String name = "buyCommodity";

    public BuyCommodity(Server s) {
        super(s);
        this.argsNumber = 3;
    }
    @Override
    public int isLegalLogin(ArrayList<String> arg){
        return server.activeUser != null ? 0 : 1;
    }
    @Override
    public boolean isLegalUser(ArrayList<String> args){
        return this.server.activeUser.identity.equals("Customer");
    }

    @Override
    public void action(ArrayList<String> args){
        if(!GrammarJudge.isLegalShopNumber(args.get(0)))
            System.out.println("Illegal shop id");
        else if(!ElementJudge.shopIsExist(this.server, Integer.parseInt(args.get(0).substring(2))))
            System.out.println("Shop id not exists");
        else if(!GrammarJudge.isLegalCommodityNumber(args.get(1)))
            System.out.println("Illegal commodity id");
        else{
            int shopNumber = Integer.parseInt(args.get(0).substring(2));
            int commodityNumber = Integer.parseInt(args.get(1).substring(2));
            Shop shop = server.shopFactory.shops.get(shopNumber - 1);
            if(!shop.commodities.containsKey(commodityNumber) ||
                    !shop.commodities.get(commodityNumber).commodityUnit.condition)
                System.out.println("Commodity id not exists");
            else if(!args.get(2).matches("[1-9]\\d*$") ||
                    Integer.parseInt(args.get(2)) > shop.commodities.get(commodityNumber).quantity)
                System.out.println("Illegal buy quantity");
            else{
                int buyQuantity = Integer.parseInt(args.get(2));
                CommodityUnit commodityUnit = server.commodityFactory.commodityUnits.get(commodityNumber - 1);
                server.orderFactory.creatOrder(shopNumber, commodityNumber, buyQuantity,
                        buyQuantity * commodityUnit.price, this.server.activeUser);
                System.out.println("Buy commodity success (orderId: O-" + server.orderFactory.orders.size() + ")");
                shop.commodities.get(commodityNumber).quantity -= buyQuantity;
            }
        }
    }
}
