package com.commands;

import com.judges.GrammarJudge;
import com.server.Server;
import com.shops.Shop;

import java.util.ArrayList;

public class ListShop extends Command{
    public String name = "listShop";
    public ListShop(Server s){super(s);}
    @Override
    public boolean isLegalArgs(ArrayList<String> args){
        return args.size() == 0 || args.size() == 1;
    }
    @Override
    public int isLegalLogin(ArrayList<String> args){
        return server.activeUser != null ? 0 : 1;
    }
    @Override
    public boolean isLegalUser(ArrayList<String> args){
        return args.size() == 0 || this.server.activeUser.identity.equals("Administrator");
    }
    @Override
    public void action(ArrayList<String> args){
        if(args.size() == 0){
            if(!server.activeUser.identity.equals("Merchant"))
                printShop(server.shopFactory.shops, server.activeUser.identity.equals("Administrator"));
            else
                printShop(server.activeUser.shops, false);
        }
        else{
            if(!GrammarJudge.isLegalCardNumber(args.get(0)))
                System.out.println("Illegal Kakafee number");
            else if(!server.map.containsKey(args.get(0)))
                System.out.println("Kakafee number not exists");
            else if(!server.map.get(args.get(0)).identity.equals("Merchant"))
                System.out.println("Kakafee number does not belong to a Merchant");
            else
                printShop(server.map.get(args.get(0)).shops, true);
        }
    }

    private void printShop(ArrayList<Shop> shops, boolean isAdmin){
        if(shops.size() == 0){
            System.out.println("Shop not exists");
            return;
        }
        boolean flag = true;
        for(Shop shop: shops){
            if(shop.condition){
                if(isAdmin)
                    System.out.print(shop.merchant.cardNumber + " ");
                System.out.println(shop);
                flag = false;
            }
        }
        if(flag)
            System.out.println("Shop not exists");
    }
}
