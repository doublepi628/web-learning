package com.commands;

import com.judges.GrammarJudge;
import com.orders.Order;
import com.server.Server;
import com.shops.Shop;
import com.users.User;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Comparator;

public class ExportMerchantOrder extends Command{
    public String name = " exportMerchantOrder";
    public ExportMerchantOrder(Server s) {
        super(s);
    }
    @Override
    public boolean isLegalArgs(ArrayList<String> args){return true;}
    @Override
    public void action(ArrayList<String> args) {
        if(args.size() == 0) {
            if (server.activeUser == null)
                System.out.println("Please log in first");
            else if (!server.activeUser.identity.equals("Merchant"))
                System.out.println("Permission denied");
            else
                printOrder(server.activeUser);
        }
        else if(args.size() == 1) {
            String arg = args.get(0);
            if(arg.equals(">") || arg.equals(">>"))
                System.out.println("Please input the redirect path");
            else if(server.activeUser == null)
                System.out.println("Please log in first");
            else if(!server.activeUser.identity.equals("Administrator"))
                System.out.println("Permission denied");
            else if(!GrammarJudge.isLegalCardNumber(arg))
                System.out.println("Illegal Kakafee number");
            else if(!server.map.containsKey(arg))
                System.out.println("Kakafee number not exists");
            else if(!server.map.get(arg).identity.equals("Merchant"))
                System.out.println("Kakafee number does not belong to a Merchant");
            else
                printOrder(server.map.get(arg));
        }
        else {
            if (!args.get(0).equals(">") && !args.get(0).equals(">>"))
                System.out.println("Illegal argument count");
            else if (!GrammarJudge.isLegalPath(args.get(1)))
                System.out.println("Illegal redirect path");
            else {
                boolean append = args.get(0).equals(">>");
                BufferedWriter writer;
                Path parentDirectory = Path.of("../data/" + args.get(1)).getParent();
                if (parentDirectory != null) {
                    try {
                        Files.createDirectories(parentDirectory);
                    } catch (IOException ignored) {}
                }
                try {
                    writer = new BufferedWriter(new FileWriter("../data/" + args.get(1), true));
                    writer.close();
                } catch (IOException e) {
                    System.out.println("Illegal redirect path");
                    return;
                }
                if(!append) {
                    try {
                        copyFileUsingJava7Files(new File("../data/" + args.get(1)), new File("../data/BACKUP.txt"));
                    } catch (Exception ignore){System.out.println("aha! -1");}
                }
                try {
                    writer = new BufferedWriter(new FileWriter("../data/" + args.get(1), append));
                } catch (IOException e) {
                    System.out.println("Illegal redirect path");
                    return;
                }
                try {
                    if (args.size() >= 4)
                        writeln(writer, "Illegal argument count");
                    else if (server.activeUser == null)
                        writeln(writer, "Please log in first");
                    else if (server.activeUser.identity.equals("Customer"))
                        writeln(writer, "Permission denied");
                    else if (server.activeUser.identity.equals("Administrator")) {
                        if (args.size() == 2)
                            writeln(writer, "Permission denied");
                        else if (!GrammarJudge.isLegalCardNumber(args.get(2)))
                            writeln(writer, "Illegal Kakafee number");
                        else if (!server.map.containsKey(args.get(2)))
                            writeln(writer, "Kakafee number not exists");
                        else if (!server.map.get(args.get(2)).identity.equals("Merchant"))
                            writeln(writer, "Kakafee number does not belong to a Merchant");
                        else if (Paths.get("../data/" + args.get(1)).normalize().equals
                                (Paths.get("../data/order/" + args.get(2) + ".txt").normalize())) {
                            if(!append) {
                                try {
                                    writer.close();
                                    copyFileUsingJava7Files(new File("../data/BACKUP.txt"), new File("../data/" + args.get(1)));
                                } catch (Exception ignore){System.out.println("aha! -2");}
                            }
                            System.out.println("The save path is the same as the redirect path");
                        }
                        else
                            printOrder(server.map.get(args.get(2)), writer);
                    } else {
                        if (args.size() == 3)
                            writeln(writer, "Permission denied");
                        else if (Paths.get("../data/" + args.get(1)).normalize().equals
                                (Paths.get("../data/order/" + server.activeUser.cardNumber + ".txt").normalize())) {
                            if(!append) {
                                try {
                                    writer.close();
                                    copyFileUsingJava7Files(new File("../data/BACKUP.txt"), new File("../data/" + args.get(1)));
                                } catch (Exception ignore){System.out.println("aha! -3");}
                            }
                            System.out.println("The save path is the same as the redirect path");
                        }
                        else
                            printOrder(server.activeUser, writer);
                    }
                } catch (IOException e) {
                    System.out.println("File operation failed");
                }
                try {
                    writer.close();
                } catch (IOException ignored) {
                }
            }
        }
    }

    private void printOrder(User user) {
        ArrayList<Order> orders = new ArrayList<>();
        for(Shop shop: user.shops)
            orders.addAll(shop.orders);
        if(orders.isEmpty())
            System.out.println("Order not exists");
        else {
            orders.sort(Comparator.comparingInt(a -> a.number));
            String filePath = "../data/order/" + user.cardNumber + ".txt";
            Path parentDirectory = Path.of(filePath).getParent();
            if (parentDirectory != null){
                try {
                    Files.createDirectories(parentDirectory);
                } catch (IOException ignored){}
            }
            try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath, false))){
                for(Order order: orders) {
                    writeln(writer, String.valueOf(order));
                    System.out.println(order);
                }
            }
            catch (IOException e) {
                System.out.println("File operation failed");
            }
        }
    }
    private void printOrder(User user, BufferedWriter writer0) {
        ArrayList<Order> orders = new ArrayList<>();
        for(Shop shop: user.shops)
            orders.addAll(shop.orders);
        if(orders.isEmpty()) {
            try {
                writeln(writer0, "Order not exists");
            }catch (Exception ignore){}
        }
        else {
            orders.sort(Comparator.comparingInt(a -> a.number));
            String filePath = "../data/order/" + user.cardNumber + ".txt";
            Path parentDirectory = Path.of(filePath).getParent();
            if (parentDirectory != null){
                try {
                    Files.createDirectories(parentDirectory);
                } catch (IOException ignored){}
            }
            try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath, false))) {
                for(Order order: orders) {
                    writeln(writer, String.valueOf(order));
                    writeln(writer0, String.valueOf(order));
                }
            }
            catch (IOException e) {
                System.out.println("File operation failed");
            }
        }
    }
    private void writeln(BufferedWriter writer, String str) throws IOException {
        writer.write(str);
        writer.newLine();
    }
    private static void copyFileUsingJava7Files(File source, File dest) throws IOException {
        if (!dest.exists() && !dest.createNewFile())
            throw new IOException("Failed to create the destination file");
        Files.copy(source.toPath(), dest.toPath(), StandardCopyOption.REPLACE_EXISTING);

    }
}
