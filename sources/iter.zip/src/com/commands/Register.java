package com.commands;
import java.util.ArrayList;
import com.users.*;
import com.server.Server;
import com.judges.GrammarJudge;
import com.users.creator.UserCreator;

public class Register extends Command {
    public String name = "register";

    public Register(Server s) {
        super(s);
        this.argsNumber = 5;
    }
    @Override
    public int isLegalLogin(ArrayList<String> arg){
        return server.activeUser == null ? 0 : 2;
    }
    @Override
    public void action(ArrayList<String> args){
        String cardNumberString = args.get(0);
        String name = args.get(1);
        String password0 = args.get(2);
        String password1 = args.get(3);
        String identityString = args.get(4);
        String nameRegex = "^[A-Za-z][A-Za-z_]{3,15}$";
        String passwordRegex = "^(?=.*[A-Za-z])(?=.*\\d)(?=.*[@_%$])[A-Za-z\\d@_%$]{8,16}$";
        if(!GrammarJudge.isLegalCardNumber(cardNumberString))
            System.out.println("Illegal Kakafee number");
        else if(server.map.containsKey(cardNumberString))
            System.out.println("Kakafee number exists");
        else if(!name.matches(nameRegex))
            System.out.println("Illegal name");
        else if(!password0.matches(passwordRegex))
            System.out.println("Illegal password");
        else if(!password0.equals(password1))
            System.out.println("Passwords do not match");
        else if(!identityString.equals("Administrator") && !identityString.equals("Merchant") && !identityString.equals("Customer"))
            System.out.println("Illegal identity");
        else{
            User newUser = UserCreator.creat(cardNumberString, name, password0,identityString);
            server.users.add(newUser);
            server.map.put(cardNumberString, newUser);
            System.out.println("Register success");
        }
    }
}