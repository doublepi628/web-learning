package com.commands;
import java.util.ArrayList;
import com.server.Server;
public class Logout extends Command {
    public String name = "logout";

    public Logout(Server s) {
        super(s);
        this.argsNumber = 0;
    }
    @Override
    public int isLegalLogin(ArrayList<String> args){
        return server.activeUser != null ? 0 : 1;
    }
    @Override
    public void action(ArrayList<String> args){
        System.out.println("Bye~");
        server.activeUser = null;
    }
}