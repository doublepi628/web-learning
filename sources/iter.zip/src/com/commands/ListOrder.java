package com.commands;

import com.judges.ElementJudge;
import com.judges.GrammarJudge;
import com.orders.Order;
import com.server.Server;
import com.shops.Shop;

import java.util.ArrayList;
import java.util.Comparator;

public class ListOrder extends Command{
    public String name = "listOrder";
    public ListOrder(Server s) {
            super(s);
        }
    @Override
    public boolean isLegalArgs(ArrayList<String> args){
        return args.size() == 0 || args.size() == 1;
    }
    @Override
public int isLegalLogin(ArrayList<String> args){
    return server.activeUser != null ? 0 : 1;
}
    @Override
    public boolean isLegalUser(ArrayList<String> args){
        return args.size() == 0 || !this.server.activeUser.identity.equals("Customer");
    }
    @Override
    public void action(ArrayList<String> args) {
        if(args.size() == 1 && !GrammarJudge.isLegalShopNumber(args.get(0)))
            System.out.println("Illegal shop id");
        else if(args.size() == 1 && !shopIsExist(Integer.parseInt(args.get(0).substring(2))))
            System.out.println("Shop id not exists");
        else {
            ArrayList<Order> orders;
            if(args.size() == 0) {
                if(server.activeUser.identity.equals("Administrator"))
                    orders = server.orderFactory.orders;
                else if(server.activeUser.identity.equals("Customer"))
                    orders = server.activeUser.orders;
                else {
                    orders = new ArrayList<>();
                    for(Shop shop: server.activeUser.shops)
                        orders.addAll(shop.orders);
                    orders.sort(Comparator.comparingInt(a -> a.number));
                }
            }
            else
                orders = server.shopFactory.shops.get(Integer.parseInt(args.get(0).substring(2)) - 1).orders;
            if(orders.size() == 0)
                System.out.println("Order not exists");
            else
                for(Order order: orders)
                    System.out.println(order);

        }
    }
    private boolean shopIsExist(int shopNumber){
        return shopNumber <= server.shopFactory.shops.size() &&
                (server.activeUser.identity.equals("Administrator")
                        || server.shopFactory.shops.get(shopNumber - 1).merchant.equals(server.activeUser));
    }
}
