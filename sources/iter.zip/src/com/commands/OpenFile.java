package com.commands;

import com.judges.GrammarJudge;
import com.server.Server;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class OpenFile extends Command{
    public String name = "OpenFile";
    public OpenFile(Server s) {
        super(s);
    }
    @Override
    public boolean isLegalArgs(ArrayList<String> args){return args.size() <= 3 && args.size() >= 1;}
    @Override
    public int isLegalLogin(ArrayList<String> arg){
        return server.activeUser != null ? 0 : 1;
    }
    @Override
    public void action(ArrayList<String> args) {
        if(args.size() == 1) {
            if(args.get(0).equals("<"))
                System.out.println("Please input the path to open the file");
            else if(!GrammarJudge.isLegalPath(args.get(0)))
                System.out.println("Illegal path");
            else
                printFile("../data/" + args.get(0));
        }
        else if(args.size() == 2) {
            if(!args.get(0).equals("<"))
                System.out.println("Illegal redirector");
            else if(!GrammarJudge.isLegalPath(args.get(1)))
                System.out.println("Illegal redirect path");
            else
                printFile("../data/" + args.get(1));
        }
        else {
            if(!args.get(1).equals("<"))
                System.out.println("Illegal redirector");
            else if(isLegalArg3(args.get(2))) {
                //File file = new File("../data/" + args.get(2));
                //if(!file.exists() || file.isDirectory())
                    //System.out.println("File not exists");
                try (BufferedReader reader = new BufferedReader(new FileReader("../data/" + args.get(2)))) {
                    String line;
                    while ((line = reader.readLine()) != null)
                        System.out.println(line);
                } catch (IOException e) {
                    System.out.println("File not exists");//
                }
            }
            else {
                if(!GrammarJudge.isLegalPath(args.get(0)))
                    System.out.println("Illegal path");
                else
                    printFile("../data/" + args.get(0));
            }
        }
    }
    private void printFile(String path) {
        //File file = new File(path);
        //if(!file.exists() || file.isDirectory())
            //System.out.println("File not exists");
        try (BufferedReader reader = new BufferedReader(new FileReader(path))) {
            String line;
            while ((line = reader.readLine()) != null)
                System.out.println(line);
        } catch (IOException e) {
            System.out.println("File not exists");//
        }
    }

    private boolean isLegalArg3(String arg) {
        if(!GrammarJudge.isLegalPath(arg))
            return false;
        File file = new File("../data/" + arg);
        return file.exists() && !file.isDirectory();
    }
}
