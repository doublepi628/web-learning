package com.commands;

import com.judges.GrammarJudge;
import com.server.Server;

import java.util.ArrayList;


public class CancelFavoriteCommodity extends Command{
    public String name = "cancelFavoriteCommodity";
    public CancelFavoriteCommodity(Server s) {
        super(s);
        this.argsNumber = 2;
    }
    @Override
    public int isLegalLogin(ArrayList<String> args){
        return server.activeUser != null ? 0 : 1;
    }
    @Override
    public boolean isLegalUser(ArrayList<String> args){
        return this.server.activeUser.identity.equals("Customer");
    }
    @Override
    public void action(ArrayList<String> args) {
        if (!GrammarJudge.isLegalShopNumber(args.get(0)))
            System.out.println("Illegal shop id");
        else if (!GrammarJudge.isLegalCommodityNumber(args.get(1)))
            System.out.println("Illegal commodity id");
        else {
            int shopNumber = Integer.parseInt(args.get(0).substring(2)), index = -1,
                    commodityNumber = Integer.parseInt(args.get(1).substring(2));
            for (int i = 0; i < server.activeUser.favorites.size(); i++) {
                if (server.activeUser.favorites.get(i).shopNumber == shopNumber && server.activeUser.favorites.get(i).commodityNumber == commodityNumber) {
                    index = i;
                    break;
                }
            } if (index == -1)
                System.out.println("Favorite not exists");
            else {
                server.activeUser.favorites.remove(index);
                System.out.println("Cancel favorite commodity success");
            }
        }
    }
}
