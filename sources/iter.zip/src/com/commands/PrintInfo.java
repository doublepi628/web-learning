package com.commands;
import java.util.ArrayList;
import com.server.Server;
import com.judges.GrammarJudge;
public class PrintInfo extends Command {
    public String name = "printInfo";

    public PrintInfo(Server s) {
        super(s);
    }
    @Override
    public boolean isLegalArgs(ArrayList<String> args){
        return args.size() == 1 || args.size() == 0;
    }
    @Override
    public int isLegalLogin(ArrayList<String> args){
        return server.activeUser != null ? 0 : 1;
    }
    @Override
    public boolean isLegalUser(ArrayList<String> args){
        return args.size() != 1 || this.server.activeUser.identity.equals("Administrator");
    }
    @Override
    public void action(ArrayList<String> args){
        if(server.activeUser == null){
            System.out.println("Please log in first");
            return;
        }
        if(args.size() == 1 &&  !server.activeUser.identity.equals("Administrator"))
            return;
        else if(args.size() == 0)
            System.out.println(server.activeUser);
        else if(args.size() == 1){
            String cardNumberString = args.get(0);
            if(!GrammarJudge.isLegalCardNumber(cardNumberString))
                System.out.println("Illegal Kakafee number");
            else if(!server.map.containsKey(args.get(0)))
                System.out.println("Kakafee number not exist");
            else
                System.out.println(server.map.get(args.get(0)));
        }
    }
}