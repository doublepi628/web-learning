package com.commands;

import com.commodities.Commodity;
import com.commodities.CommodityUnit;
import com.functions.SortMap;
import com.judges.GrammarJudge;
import com.server.Server;
import com.shops.Shop;

import java.util.*;

public class ListCommodity extends Command{
    public String name = "listCommodity";
    public ListCommodity(Server s){super(s);}
    @Override
    public boolean isLegalArgs(ArrayList<String> args){
        return args.size() == 0 || args.size() == 1;
    }
    @Override
    public int isLegalLogin(ArrayList<String> args){
        return server.activeUser != null ? 0 : 1;
    }
    @Override
    public void action(ArrayList<String> args){
        if(args.isEmpty()) {
            if(server.activeUser.identity.equals("Merchant"))
                printCommodityValue(server.activeUser.shops);
            else
                printCommodityValue(server.shopFactory.shops);
        }
        else
        {
            if(!GrammarJudge.isLegalShopNumber(args.get(0)))
                System.out.println("Illegal shop id");
            else if(server.activeUser.identity.equals("Merchant")) {
                int id = Integer.parseInt(args.get(0).substring(2));
                if(id <= server.shopFactory.shops.size() && server.shopFactory.shops.get(id - 1).condition &&
                        server.shopFactory.shops.get(id - 1).merchant.equals(server.activeUser))
                    printShopCommodity(server.shopFactory.shops.get(id - 1));
                else
                    System.out.println("Shop id not exists");
            }
            else{
                int id = Integer.parseInt(args.get(0).substring(2));
                if(id <= server.shopFactory.shops.size() && server.shopFactory.shops.get(id - 1).condition)
                    printShopCommodity(server.shopFactory.shops.get(id - 1));
                else
                    System.out.println("Shop id not exists");
            }
        }
    }

    private void printCommodityValue(ArrayList<Shop> shops){
        boolean flag = true;
        for(Shop shop: shops){
            if(!shop.condition)
                continue;
            List<Map.Entry<Integer, Commodity>> list = SortMap.sortMap0(shop.commodities);
            for (Map.Entry<Integer, Commodity> entry : list) {
                if(entry.getValue().commodityUnit.condition){
                    flag = false;
                    System.out.println(entry.getValue());
                }
            }
        }
        if(flag)
            System.out.println("Commodity not exists");
    }

    private void printShopCommodity(Shop shop){
        if(shop.commodities.size() == 0){
            System.out.println("Commodity not exists");
            return;
        }
        boolean flag = true;
        List<Map.Entry<Integer, Commodity>> list = SortMap.sortMap0(shop.commodities);
        for (Map.Entry<Integer, Commodity> entry : list){
            if(entry.getValue().commodityUnit.condition){
                System.out.println(entry.getValue());
                flag = false;
            }
        }
        if(flag)
            System.out.println("Commodity not exists");
    }

}
