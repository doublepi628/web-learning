package com.commands;

import com.commodities.CommodityUnit;
import com.commodities.Favorite;
import com.judges.ElementJudge;
import com.server.Server;
import com.shops.Shop;

import java.util.ArrayList;

public class BuyFavoriteCommodity extends Command{
    public String name = "buyFavoriteCommodity";
    public BuyFavoriteCommodity(Server s) {
        super(s);
        this.argsNumber = 0;
    }
    @Override
    public int isLegalLogin(ArrayList<String> arg){
        return server.activeUser != null ? 0 : 1;
    }
    @Override
    public boolean isLegalUser(ArrayList<String> args){
        return this.server.activeUser.identity.equals("Customer");
    }
    @Override
    public void action(ArrayList<String> args){
        if (server.activeUser.favorites.isEmpty())
            System.out.println("Favorite not exists");
        else {
            for (Favorite favorite: server.activeUser.favorites) {
                int shopNumber = favorite.shopNumber, commodityNumber = favorite.commodityNumber, quantity = favorite.quantity;
                if (!ElementJudge.shopIsExist(server, shopNumber))
                    System.out.println("Shop id not exists");
                else {
                    Shop shop = server.shopFactory.shops.get(shopNumber - 1);
                    if(!shop.commodities.containsKey(commodityNumber) ||
                            !shop.commodities.get(commodityNumber).commodityUnit.condition)
                        System.out.println("Commodity id not exists");
                    else if (shop.commodities.get(commodityNumber).quantity < quantity)
                        System.out.println("Illegal buy quantity");
                    else {
                        CommodityUnit commodityUnit = server.commodityFactory.commodityUnits.get(commodityNumber - 1);
                        server.orderFactory.creatOrder(shopNumber, commodityNumber, quantity,
                                quantity * commodityUnit.price, this.server.activeUser);
                        System.out.println(server.orderFactory.orders.get(server.orderFactory.orders.size() - 1));
                        shop.commodities.get(commodityNumber).quantity -= quantity;
                    }
                }
            } server.activeUser.favorites.clear();

        }
    }
}
