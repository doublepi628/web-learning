package com.commands;

import com.commodities.Commodity;
import com.functions.SortMap;
import com.judges.GrammarJudge;
import com.server.Server;
import com.shops.Shop;
import java.util.*;

public class SearchCommodity extends Command{
    public String name = "searchCommodity";
    public SearchCommodity(Server s) {
        super(s);
        this.argsNumber = 1;
    }
    @Override
    public int isLegalLogin(ArrayList<String> args){
        return server.activeUser != null ? 0 : 1;
    }
    @Override
    public void action(ArrayList<String> args) {
        if(!GrammarJudge.isLegalName(args.get(0))){
            System.out.println("Illegal commodity name");
            return;
        }
        ArrayList<Shop> shops;
        if(server.activeUser.identity.equals("Merchant"))
            shops = server.activeUser.shops;
        else
            shops = server.shopFactory.shops;
        boolean flag = true;
        for(Shop shop: shops){
            if(!shop.condition)
                continue;
            List<Map.Entry<Integer, Commodity>> list = SortMap.sortMap0(shop.commodities);
            for(Map.Entry<Integer, Commodity> entry : list) {
                if(entry.getValue().commodityUnit.condition
                        && entry.getValue().commodityUnit.name.equals(args.get(0)) && entry.getValue().quantity > 0){
                    flag = false;
                    System.out.println(entry.getValue());
                }
            }
        }
        if(flag)
            System.out.println("Commodity not exists");
    }
}
