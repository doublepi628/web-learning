package com.commands;

import com.commodities.Favorite;
import com.server.Server;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;

public class ReadFavoriteCommodity extends Command{
    public ReadFavoriteCommodity(Server s) {
        super(s);
        this.argsNumber = 1;
    }
    @Override
    public int isLegalLogin(ArrayList<String> args){
        return server.activeUser != null ? 0 : 1;
    }
    @Override
    public boolean isLegalUser(ArrayList<String> args){
        return this.server.activeUser.identity.equals("Customer");
    }
    @Override
    public void action(ArrayList<String> args) {
        Path path = Paths.get("../data/" + args.get(0));
        try {
            if (!Files.exists(path))
                System.out.println("File not exists");
            else {
                try {
                    ObjectInputStream inputStream = new ObjectInputStream(new FileInputStream("../data/" + args.get(0)));
                    while (true) {
                        try {
                            Favorite favorite = (Favorite) inputStream.readObject();
                            boolean flag = true;
                            for (int i = 0; i < server.activeUser.favorites.size(); i++) {
                                if (server.activeUser.favorites.get(i).shopNumber == favorite.shopNumber && server.activeUser.favorites.get(i).commodityNumber == favorite.commodityNumber) {
                                    server.activeUser.favorites.get(i).quantity += favorite.quantity;
                                    flag = false;
                                    break;
                                }
                            }
                            if (flag)
                                server.activeUser.favorites.add(new Favorite(favorite.shopNumber, favorite.commodityNumber,
                                        favorite.quantity, server.commodityFactory.commodityUnits.get(favorite.commodityNumber - 1).price));
                        } catch (EOFException e) {
                            break; // Break out of the loop when the end of the stream is reached
                        } catch (ClassNotFoundException ignored) {
                            System.out.println("File operation failed");
                        }
                    } System.out.println("Read favorite commodity success");
                } catch(Exception e){ System.out.println("zhaodaola!!!");}
            }
        } catch (Exception e){ System.out.println("File operation failed");};
    }
}
