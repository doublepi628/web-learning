package com.commands;

import com.judges.ElementJudge;
import com.judges.GrammarJudge;
import com.server.Server;

import java.util.ArrayList;

public class FinishOrder extends Command{
    public String name = "finishOrder";
    public FinishOrder(Server s) {
        super(s);
        this.argsNumber = 1;
    }
    @Override
    public int isLegalLogin(ArrayList<String> arg){
        return server.activeUser != null ? 0 : 1;
    }
    @Override
    public boolean isLegalUser(ArrayList<String> args){
        return this.server.activeUser.identity.equals("Customer");
    }
    @Override
    public void action(ArrayList<String> args) {
        if(!GrammarJudge.isLegalOrderNumber(args.get(0)))
            System.out.println("Illegal order id");
        else if(!ElementJudge.orderIsExist(this.server, (Integer.parseInt(args.get(0).substring(2)))))
            System.out.println("Order id not exists");
        else if(server.orderFactory.orders.get(Integer.parseInt(args.get(0).substring(2)) - 1).statusNum == 1)
            System.out.println("Order already canceled");
        else if(server.orderFactory.orders.get(Integer.parseInt(args.get(0).substring(2)) - 1).statusNum == 2)
            System.out.println("Order already finished");
        else {
            server.orderFactory.orders.get(Integer.parseInt(args.get(0).substring(2)) - 1).statusNum = 2;
            System.out.println("Finish order success");

        }
    }
}
