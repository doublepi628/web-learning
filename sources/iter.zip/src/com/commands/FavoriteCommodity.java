package com.commands;

import com.commodities.Favorite;
import com.judges.ElementJudge;
import com.judges.GrammarJudge;
import com.server.Server;

import java.util.ArrayList;

public class FavoriteCommodity extends Command{
    public String name = "favoriteCommodity";
    public FavoriteCommodity(Server s) {
        super(s);
        this.argsNumber = 3;
    }
    @Override
    public int isLegalLogin(ArrayList<String> args){
        return server.activeUser != null ? 0 : 1;
    }
    @Override
    public boolean isLegalUser(ArrayList<String> args){
        return this.server.activeUser.identity.equals("Customer");
    }
    @Override
    public void action(ArrayList<String> args) {
        if (!GrammarJudge.isLegalShopNumber(args.get(0)))
            System.out.println("Illegal shop id");
        else if (!ElementJudge.shopIsExist(this.server, Integer.parseInt(args.get(0).substring(2))))
            System.out.println("Shop id not exists");
        else if (!GrammarJudge.isLegalCommodityNumber(args.get(1)))
            System.out.println("Illegal commodity id");
        else {
            int commodityNumber = Integer.parseInt(args.get(1).substring(2)),
                    shopNumber = Integer.parseInt(args.get(0).substring(2));
            if (commodityNumber > server.commodityFactory.commodityUnits.size() ||
                    !server.commodityFactory.commodityUnits.get(commodityNumber - 1).condition ||
                    !server.shopFactory.shops.get(shopNumber - 1).commodities.containsKey(commodityNumber))
                System.out.println("Commodity id not exists");
            else if (!args.get(2).matches("^[1-9]\\d*$"))
                System.out.println("Illegal commodity quantity");
            else {
                boolean flag = true;
                for (int i = 0; i < server.activeUser.favorites.size(); i++) {
                    if (server.activeUser.favorites.get(i).shopNumber == shopNumber && server.activeUser.favorites.get(i).commodityNumber == commodityNumber) {
                        server.activeUser.favorites.get(i).quantity += Integer.parseInt(args.get(2));
                        flag = false;
                        break;
                    }
                }
                if (flag)
                    server.activeUser.favorites.add(new Favorite(shopNumber, commodityNumber,
                        Integer.parseInt(args.get(2)), server.commodityFactory.commodityUnits.get(commodityNumber - 1).price));
                System.out.println("Favorite commodity success");
            }
        }
    }
}
