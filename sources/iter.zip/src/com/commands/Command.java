package com.commands;
import java.util.ArrayList;
import com.server.Server;
public class Command {
    public String name;
    int argsNumber;
    Server server;
    public Command(Server s){
        server = s;
    }
    public void action(ArrayList<String> args){
    }
    public boolean isLegalArgs(ArrayList<String> args){return args.size() == argsNumber;}
    public int isLegalLogin(ArrayList<String> args){return 0;}// 0: no problem 1: need to login 2: need no activeUser

    public boolean isLegalUser(ArrayList<String> args){return true;}
}

