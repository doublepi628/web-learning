package com.commands;

import com.commodities.Commodity;
import com.commodities.CommodityUnit;
import com.judges.ElementJudge;
import com.server.Server;
import com.judges.GrammarJudge;
import com.shops.Shop;

import java.util.ArrayList;

public class PutCommodity extends Command{
    public String name = "putCommodity";

    public PutCommodity(Server s) {super(s);}
    @Override
    public boolean isLegalArgs(ArrayList<String> args){
        return args.size() == 3 || args.size() == 4;
    }
    @Override
    public int isLegalLogin(ArrayList<String> args){
        return server.activeUser != null ? 0 : 1;
    }
    @Override
    public boolean isLegalUser(ArrayList<String> args){
        return this.server.activeUser.identity.equals("Merchant");
    }
    @Override
    public void action(ArrayList<String> args){
        if(!GrammarJudge.isLegalShopNumber(args.get(0)))
            System.out.println("Illegal shop id");
        else if(!shopIsExist(Integer.parseInt(args.get(0).substring(2))))
            System.out.println("Shop id not exists");
        else if(args.size() == 3 && !GrammarJudge.isLegalCommodityNumber(args.get(1)))
            System.out.println("Illegal commodity id");
        else if(args.size() == 4 && !GrammarJudge.isLegalName(args.get(1)))
            System.out.println("Illegal commodity name");
        else if(args.size() == 4 && !GrammarJudge.isLegalPrice(args.get(2)))
            System.out.println("Illegal commodity price");
        else if(args.size() == 3 && !commodityIsExist(Integer.parseInt(args.get(0).substring(2)), Integer.parseInt(args.get(1).substring(2))))
            System.out.println("Commodity id not exists");
        else if(args.size() == 3 && !args.get(2).matches("^[1-9]\\d*$"))
            System.out.println("Illegal commodity quantity");
        else if(args.size() == 4 && !args.get(3).matches("^[1-9]\\d*$"))
            System.out.println("Illegal commodity quantity");
        else if(args.size() == 3){
            Shop shop = server.shopFactory.shops.get(Integer.parseInt(args.get(0).substring(2)) - 1);
            int quantity = Integer.parseInt(args.get(2));
            int commodityNumber = Integer.parseInt(args.get(1).substring(2));
            for(Commodity commodity: shop.commodities.values()) {
                if(commodity.commodityUnit.number == commodityNumber){
                    commodity.quantity += quantity;
                    System.out.println("Put commodity success (commodityId: C-" + commodityNumber + ")");
                    return;
                }
            }
            shop.addCommodities(server.commodityFactory.commodityUnits.get(commodityNumber - 1), quantity);
            System.out.println("Put commodity success (commodityId: C-" + commodityNumber + ")");
        }
        else{
            Shop shop = server.shopFactory.shops.get(Integer.parseInt(args.get(0).substring(2)) - 1);
            server.commodityFactory.creatCommodity(shop, args.get(1), Double.parseDouble(args.get(2)), Integer.parseInt(args.get(3)));
            System.out.println("Put commodity success (commodityId: C-" + server.commodityFactory.commodityUnits.size() + ")");
        }
    }

    private boolean shopIsExist(int shopNumber){
        return ElementJudge.shopIsExist(server, shopNumber) &&
                server.shopFactory.shops.get(shopNumber - 1).merchant.equals(server.activeUser);
    }

    private boolean commodityIsExist(int shopNumber, int commodityNumber){
        if(commodityNumber > server.commodityFactory.commodityUnits.size())
            return false;
        Shop shop = server.shopFactory.shops.get(shopNumber - 1);
        CommodityUnit commodityUnit = server.commodityFactory.commodityUnits.get(commodityNumber - 1);
        return commodityUnit.condition && shop.merchant.equals(commodityUnit.merchant);
    }
}