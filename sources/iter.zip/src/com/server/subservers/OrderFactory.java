package com.server.subservers;

import com.orders.Order;
import com.server.Server;
import com.users.User;

import java.util.ArrayList;

public class OrderFactory {
    public ArrayList<Order> orders;
    Server server;
    public OrderFactory(Server server0) {
        this.orders = new ArrayList<>();
        this.server = server0;
    }

    public void creatOrder(int sId, int cId, int cNum, double price0, User customer) {
        Order order = new Order(sId, cId, cNum, price0, orders.size() + 1, customer);
        orders.add(order);
        this.server.activeUser.orders.add(order);
        this.server.shopFactory.shops.get(sId - 1).orders.add(order);
    }
}
