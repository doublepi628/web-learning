package com.server.subservers;

import java.util.ArrayList;
import com.server.Server;
import com.shops.Shop;
import com.users.User;

public class ShopFactory {
    public ArrayList<Shop> shops;
    Server server;

    public ShopFactory(Server server0){
        this.shops = new ArrayList<>();
        this.server = server0;
    }

    public void creatShop(String name0, User merchant){
        this.shops.add(new Shop(name0, this.shops.size() + 1, merchant));
        server.activeUser.shops.add(this.shops.get(this.shops.size() - 1));
    }
}
