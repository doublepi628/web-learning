package com.server.subservers;

import com.commodities.CommodityUnit;
import com.server.Server;
import com.shops.Shop;

import java.util.ArrayList;

public class CommodityFactory {
    public ArrayList<CommodityUnit> commodityUnits;
    Server server;
    public CommodityFactory(Server server0){
        this.commodityUnits = new ArrayList<>();
        this.server = server0;
    }

    public void creatCommodity(Shop shop0, String name0, double price0, int quantity0){
        CommodityUnit commodityUnit = new CommodityUnit(name0, this.commodityUnits.size() + 1, price0, shop0.merchant);
        commodityUnits.add(commodityUnit);
        shop0.addCommodities(commodityUnit, quantity0);
    }
}
