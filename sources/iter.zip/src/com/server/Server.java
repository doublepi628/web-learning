package com.server;

import java.util.*;

import com.server.subservers.CommodityFactory;
import com.server.subservers.OrderFactory;
import com.server.subservers.ShopFactory;
import com.users.User;
import com.commands.*;
public class Server {
    public ArrayList<User> users;
    public Map<String, User> map = new HashMap<>();
    public Map<String, Command> commandMap = new HashMap<>();
    public boolean working;
    public User activeUser;
    public ShopFactory shopFactory;
    public CommodityFactory commodityFactory;
    public OrderFactory orderFactory;
    public Server() {
        working = true;
        users = new ArrayList<User>();
        activeUser = null;
        shopFactory = new ShopFactory(this);
        commodityFactory = new CommodityFactory(this);
        orderFactory = new OrderFactory(this);
        commandMap.put("quit", new Quit(this));
        commandMap.put("register", new Register(this));
        commandMap.put("login", new Login(this));
        commandMap.put("logout", new Logout(this));
        commandMap.put("printInfo", new PrintInfo(this));
        commandMap.put("registerShop", new RegisterShop(this));
        commandMap.put("putCommodity", new PutCommodity(this));
        commandMap.put("listShop", new ListShop(this));
        commandMap.put("listCommodity", new ListCommodity(this));
        commandMap.put("searchCommodity", new SearchCommodity(this));
        commandMap.put("buyCommodity", new BuyCommodity(this));
        commandMap.put("removeCommodity", new RemoveCommodity(this));
        commandMap.put("cancelShop", new CancelShop(this));
        commandMap.put("putCommodityBatch", new PutCommodityBatch(this));
        commandMap.put("cancelOrder", new CancelOrder(this));
        commandMap.put("finishOrder", new FinishOrder(this));
        commandMap.put("listOrder", new ListOrder(this));
        commandMap.put("exportMerchantOrder", new ExportMerchantOrder(this));
        commandMap.put("openFile", new OpenFile(this));
        commandMap.put("favoriteCommodity", new FavoriteCommodity(this));
        commandMap.put("cancelFavoriteCommodity", new CancelFavoriteCommodity(this));
        commandMap.put("listFavoriteCommodity", new ListFavoriteCommodity(this));
        commandMap.put("uploadFavoriteCommodity", new UploadFavoriteCommodity(this));
        commandMap.put("readFavoriteCommodity", new ReadFavoriteCommodity(this));
        commandMap.put("buyFavoriteCommodity", new BuyFavoriteCommodity(this));
    }

    public void executeCommand(String line){
        String[] words = line.split("\\s+");
        if (!commandMap.containsKey(words[0]))
            System.out.println("Command '" + words[0] + "' not found");
        else {
            ArrayList<String> args = new ArrayList<>(Arrays.asList(words).subList(1, words.length));
            if (!commandMap.get(words[0]).isLegalArgs(args))
                System.out.println("Illegal argument count");
            else {
                if (commandMap.get(words[0]).isLegalLogin(args) == 1)
                    System.out.println("Please log in first");
                else if (commandMap.get(words[0]).isLegalLogin(args) == 2)
                    System.out.println("Already logged in");
                else {
                    if (!commandMap.get(words[0]).isLegalUser(args))
                        System.out.println("Permission denied");
                    else
                        commandMap.get(words[0]).action(args);
                }
            }
        }
    }
}
