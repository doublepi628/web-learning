package com.judges;
public class GrammarJudge {
    public static boolean isLegalCardNumber(String cardNumberString){
        if(!cardNumberString.matches("\\d+"))
            return false;
        long cardNumber = Long.parseLong(cardNumberString);
        if(1 > cardNumber / 100000000 || cardNumber / 100000000 > 4500)
            return false;
        else if(1785 > cardNumber / 10000 % 10000 || cardNumber / 10000 % 10000 > 1886)
            return false;
        else
            return 1000 <= cardNumber % 10000 && cardNumber % 10000 <= 3000;
    }
    public static boolean isLegalName(String name){// shop name or commodity name
        String regex = "^[a-zA-Z][a-zA-Z_-]{0,49}$";
        return name.matches(regex);
    }
    public static  boolean isLegalShopNumber(String shopNumberString){
        return shopNumberString.matches("^S-[1-9]\\d*$");
    }
    public static  boolean isLegalCommodityNumber(String commodityNumberString){
        return commodityNumberString.matches("^C-[1-9]\\d*$");
    }
    public static  boolean isLegalOrderNumber(String commodityNumberString){
        return commodityNumberString.matches("^O-[1-9]\\d*$");
    }
    public static  boolean isLegalPrice(String arg){
        if(!arg.matches("^(\\d+|\\d*\\.\\d{1,2})$"))
            return false;
        double price = Double.parseDouble(arg);
        return price > 0 && price <= 99999999.99;
    }
    public static boolean isLegalPath(String arg) {
        return arg.matches("^[^*?\"<>|]+$");
    }
}
