package com.judges;

import com.server.Server;

public class ElementJudge {
    public static boolean shopIsExist(Server server, int shopNumber) {
        return shopNumber <= server.shopFactory.shops.size() && server.shopFactory.shops.get(shopNumber - 1).condition;
    }
    public static boolean orderIsExist(Server server, int num) {
        return num <= server.orderFactory.orders.size() &&
                server.orderFactory.orders.get(num - 1).customer.equals(server.activeUser);
    }
}
