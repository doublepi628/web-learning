package com.orders;

import com.users.User;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Map;

public class Order {
    public int statusNum;
    public int shopId, commodityId, commodityNum, number;
    public double price;
    public User customer;
    public static final ArrayList<String> statusMap = new ArrayList<>(Arrays.asList("pending", "canceled", "finished"));

    public Order(int sId, int cId, int cNum, double price0, int number0, User customer0){
        this.statusNum = 0;
        this.shopId = sId;
        this.commodityId = cId;
        this.commodityNum = cNum;
        this.price = price0;
        this.number = number0;
        this.customer = customer0;
    }

    @Override
    public String toString(){
        return String.format("O-%d: S-%d C-%d %d %.2fyuan %s", this.number, this.shopId, this.commodityId,
                this.commodityNum, this.price, statusMap.get(this.statusNum));
    }
}
