package com.shops;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import com.commodities.Commodity;
import com.commodities.CommodityUnit;
import com.orders.Order;
import com.users.User;

public class Shop {

    public String name;
    public int number;
    public boolean condition; //open or closed
    public User merchant;
    public Map<Integer, Commodity> commodities;
    public ArrayList<Order> orders;

    public Shop(String name0, int number0, User merchant0){
        this.name = name0;
        this.number = number0;
        this.condition = true;
        this.commodities = new HashMap<>();
        this.merchant = merchant0;
        this.orders = new ArrayList<>();
    }

    public void addCommodities(CommodityUnit commodityUnit, int quantity0){
        if(this.commodities.containsKey(commodityUnit.number))
            this.commodities.get(commodityUnit.number).quantity += quantity0;
        else {
            Commodity commodity = new Commodity(commodityUnit, quantity0, this);
            commodityUnit.commodities.add(commodity);
            commodities.put(commodityUnit.number, commodity);
        }
    }

    @Override
    public String toString(){
        return "S-" + this.number + " " + this.name;
    }
}
