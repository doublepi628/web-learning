package com.commodities;

import com.shops.Shop;
import com.users.User;
import java.util.ArrayList;

public class CommodityUnit {
    public String name;
    public int number;
    public boolean condition; // available or unavailable
    public double price;
    public ArrayList<Commodity> commodities;
    public User merchant;

    public CommodityUnit(String name0, int number0, double price0, User merchant0){
        this.name = name0;
        this.number = number0;
        this.price = price0;
        this.commodities = new ArrayList<>();
        this.condition = true;
        this.merchant = merchant0;
    }
}
