package com.commodities;

import com.shops.Shop;
public class Commodity {
    public CommodityUnit commodityUnit;
    public Shop shop;
    public int quantity;
    public Commodity(CommodityUnit commodityUnit0, int quantity0, Shop shop0) {
        this.commodityUnit = commodityUnit0;
        this.quantity = quantity0;
        this.shop = shop0;
    }
    @Override
    public String toString(){
        return String.format("S-%d: C-%d %s %.2fyuan %d", this.shop.number, this.commodityUnit.number,
                this.commodityUnit.name, this.commodityUnit.price, this.quantity);
    }
}
