package com.commodities;

import java.io.Serializable;

public class Favorite implements Serializable {
    public int shopNumber, commodityNumber, quantity;
    public double price;
    public Favorite(int shopNum, int commodityNum, int quantity0, double price0) {
        this.shopNumber = shopNum;
        this.commodityNumber = commodityNum;
        this.quantity = quantity0;
        this.price = price0;
    }
    @Override
    public String toString() {
        return String.format("S-%d: C-%d %d %.2fyuan", this.shopNumber, this.commodityNumber, this.quantity, this.price);
    }
}
