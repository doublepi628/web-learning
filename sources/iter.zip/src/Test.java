import java.util.Scanner;
import com.server.Server;
public class Test {
    public static void main(String[] args){
        Scanner scanner = new Scanner(System.in);
        Server server = new Server();
        while(server.working && scanner.hasNextLine()){
            String line = scanner.nextLine();
            server.executeCommand(line);
        }
    }
}
