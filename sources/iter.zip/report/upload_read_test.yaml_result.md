# upload_read_test.yaml 评测情况

## 通过情况

Congratulations, AC!
